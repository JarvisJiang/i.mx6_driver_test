/*
 * Copyright 2014, Freescale Semiconductor
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */

#ifndef _ASM_ARMV8_FSL_LSCH3_GPIO_H_
#define _ASM_ARMV8_FSL_LSCH3_GPIO_H_
#endif	/* _ASM_ARMV8_FSL_LSCH3_GPIO_H_ */
