/*
 * Copyright 2014 Freescale Semiconductor, Inc.
 *
 * SPDX-License-Identifier:	GPL-2.0+
 *
 */

#ifndef __ASM_ARCH_FSL_LSCH3_IMX_REGS_H_
#define __ASM_ARCH_FSL_LSCH3_IMX_REGS_H_

#define I2C_QUIRK_REG	/* enable 8-bit driver */

#endif /* __ASM_ARCH_FSL_LSCH3_IMX_REGS_H_ */
